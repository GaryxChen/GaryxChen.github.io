﻿
Steps: (seam carving.exe)
1. Run seam carving.exe.
2. Enter the name of a *.bmp file in the root directory, such as 1.bmp or 2.bmp.
3. Wait for Result_1.bmp or Result_2.bmp to be generated.

Steps: (seam carving_M.exe)
1. Run seam carving_M.exe.
2. Enter the name of a *.bmp file in the root directory, such as 2.bmp.
3. Enter the name of a *.bmp file as a mask in the root directory, such as 2m.bmp.
4. Wait for the Result_2.bmp to be generated.