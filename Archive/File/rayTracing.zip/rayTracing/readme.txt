﻿
※ rayTracing.exe requires DirectX 10 or higher to run.n.

Steps:
1. Select a *.nff file in the "balls" directory.
2. Move the selected *.nff file to the root directory and rename it to "ball.nff".
3. Run rayTracing.exe.
4. Wait for the RESULT.bmp to be generated.